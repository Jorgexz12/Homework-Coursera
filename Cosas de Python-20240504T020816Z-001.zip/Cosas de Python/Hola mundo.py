print("Hola, que onda")
print("Ola, k ase")
