print("================================")
print("Dias de vacaciones en la empresa")
print("================================ \n ")
nombre=str(input("¿Como te llamas? \n"))
print("En que departamento te encuentras? \n ")
departamento=int(input("Atencion a cliente (1) \nDepartamento de logistica (2) \nGerencia (3) \n"))

antiguedad=int(input("Cuantos años de servicio tienes en la empresa? \n"))

if departamento==1:
    if antiguedad<=1:
        a=6
        print("Hola ",nombre,"por su departamento de atencion a clientes y su antiguedad de ",antiguedad, "años, usted tendra ",a," dias de vacaciones")
    if antiguedad>1 and antiguedad<=6:
        a=14
        print("Hola ",nombre,"por su departamento de atencion a clientes y su antiguedad de ",antiguedad, "años, usted tendra ",a," dias de vacaciones")
    else:
        a=20
        print("Hola ",nombre,"por su departamento de atencion a clientes y su antiguedad de ",antiguedad, "años, usted tendra ",a," dias de vacaciones")
if departamento==2:
    if antiguedad<=1:
        a=7
        print("Hola ",nombre,"por su departamento de logistica y su antiguedad de ",antiguedad, "años, usted tendra ",a," dias de vacaciones")
    if antiguedad>1 and antiguedad<=6:
        a=15
        print("Hola ",nombre,"por su departamento de logistica y su antiguedad de ",antiguedad, "años, usted tendra ",a," dias de vacaciones")
    else:
        a=22
        print("Hola ",nombre,"por su departamento de logistica y su antiguedad de ",antiguedad, "años, usted tendra ",a," dias de vacaciones")
if departamento==3:
    if antiguedad<=1:
        a=10
        print("Hola ",nombre,"por su departamento de gerencia y su antiguedad de ",antiguedad, "años, usted tendra ",a," dias de vacaciones")
    if antiguedad>1 and antiguedad<=6:
        a=20
        print("Hola ",nombre,"por su departamento de gerencia y su antiguedad de ",antiguedad, "años, usted tendra ",a," dias de vacaciones")
    else:
        a=30
        print("Hola ",nombre,"por su departamento de gerencia y su antiguedad de ",antiguedad, "años, usted tendra ",a," dias de vacaciones")
else:
    print("error, no existe ese departamento")
    
