op=int(input("Que operacion quieres realizar? \n 1 (suma) 2(resta) \n"))

one=int(input("Primer numero "))
sec=int(input("Segundo numero "))
if op==1:
 print("La suma de los numeros es ", one+sec)
else:
 print("La resta de los numeros es ", one-sec) 

