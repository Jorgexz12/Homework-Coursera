print("Comparador de numeros \n")
x=float(input("Introduce el primer numero \n "))
y=float(input("Introduce el segundo numero \n "))

if x>y:
    print(x," es mayor a ",y)
else:
    print(y," es mayor a ",x)
