
x=int(input("Di un escribe entero positivo \n "))

i=1

while x>=i:
   
    print(i, end=",")
    i+=1
    

