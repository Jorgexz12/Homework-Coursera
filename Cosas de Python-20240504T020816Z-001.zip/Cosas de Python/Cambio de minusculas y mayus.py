titulo="Bienvenido a mi nuevo programa"
tit=titulo.title()
print("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&")
print(tit)
print("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&& \n ")

name=str(input("Como te llamas? \n "))

x=name.upper()
y=name.lower()
z=name.capitalize()
a=name.swapcase()

print(x + " \n ")
print(y + " \n ")
print(z + " \n ")
print(a + " \n ")

