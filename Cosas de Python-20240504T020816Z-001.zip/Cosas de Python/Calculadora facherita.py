print("============================")
print("La calculadora mas facherita")
print("============================ \n")


i=1
while i==1:
    print("Opciones de la calculadora facherita \n")
    print("1.-Suma \n2.-Resta \n3.-Multiplicacion \n4.-exponente \n5.-Division \n")
    opc=int(input("Seleccione la opcion con su numero entero correspondiente \n"))
    if opc==1:
        x=int(input("Cuales el primer numero a sumar? "))
        y=int(input("Cuales el segundo numero a sumar? "))
        z=x+y
        print("El resultado de la suma es ",z)
        i=int(input("Quiere realizar otra operacion?  1.-Si 2.-No \n"))
    elif opc==2:
        x=int(input("Cuales el primer numero a restar? "))
        y=int(input("Cuales el segundo numero a restar? "))
        z=x-y
        print("El resultado de la resta es ",z)
        i=int(input("Quiere realizar otra operacion?  1.-Si 2.-No \n"))
    elif opc==3:
        x=int(input("Cuales el primer numero a multiplicar? "))
        y=int(input("Cuales el segundo numero a multiplicar? "))
        z=x*y
        print("El resultado de la multiplicacion es ",z)
        i=int(input("Quiere realizar otra operacion?  1.-Si 2.-No"))
    elif opc==4:
        x=int(input("Cual es el numero a elevar? "))
        y=int(input("a que exponente se elevara el numero? "))
        z=x**y
        print("El resultado de elevar ", x , " a la potencia ", y, "es igual a ", z)
        i=int(input("Quiere realizar otra operacion?  1.-Si 2.-No \n"))
    elif opc==5:
        x=int(input("que numero dividiras? "))
        y=int(input("en cuantas partes se dividira el numero? "))
        z=x/y
        print("El resultado de la multiplicacion es ",z)
        i=int(input("Quiere realizar otra operacion?  1.-Si 2.-No \n"))

    elif opc>5:
        print("error en la seleccion de opciones")
        i=int(input("Quiere intentarlo de nuevo?  1.-Si 2.-No \n"))
print("Bye,bye oni chan")

