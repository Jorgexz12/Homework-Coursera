print("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&")
print("Bienvenido a mi nuevo programa")
print("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&& \n ")

name=str(input("como te llamas? \n "))
x=int(input("Elije un numero entero \n"))

i=1
while i<=x:
    print(name)
    i+=1
